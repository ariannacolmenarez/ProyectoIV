        
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <?php require_once("content/component/script.php");
  ?>
</body>

</html>
<?php
require_once("view/proveedores.php");
require_once("view/clientes.php");
require_once("view/usuarios.php");
require_once("view/perfil.php");
require_once("view/chats.php");


?>