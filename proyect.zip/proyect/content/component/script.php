  <!-- plugins:js -->
  <script src="<?= _THEME_ ?>base/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <script src="<?= _THEME_ ?>chart.js/Chart.min.js"></script>
  <script src="<?= _THEME_ ?>js/jquery.cookie.js"></script>
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="<?= _THEME_ ?>js/chart.js"></script>
  <script src="<?= _THEME_ ?>js/off-canvas.js"></script>
  <script src="<?= _THEME_ ?>js/hoverable-collapse.js"></script>
  <script src="<?= _THEME_ ?>js/template.js"></script>
  <script src="<?= _THEME_ ?>js/todolist.js"></script>
  <script type="text/javascript" src="<?= _THEME_ ?>DataTables/datatables.min.js"></script>

  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="<?= _THEME_ ?>js/dashboard.js"></script>
  <!-- End custom js for this page-->
  <script src="<?= _THEME_ ?>js/jquery-ui.min.js"></script>
  <script src="<?= _THEME_ ?>js/jquery.validate.js"></script>
  <script src="<?= _THEME_ ?>js/messages_es.js"></script>
  <script src="<?= _THEME_ ?>js/additional-methods.js"></script>
  <script src="<?= _THEME_ ?>js/bootstrap-datepicker.min.js"></script>
  <script src="<?= _THEME_ ?>js/week.js"></script>
  <script src="<?= _THEME_ ?>js/month.js"></script>
  <script src="<?= _THEME_ ?>js/year.js"></script>  
  <script src="<?= _THEME_ ?>js/scripts/alerts/logout.js"></script>
