<?php
namespace content\controllers;

 class errorController{
     
    function error(){
        require("view/error.php");
    } 
 }

 

?>