$(document).ready(function() {


    
});

function funcionr(vari){
    if (vari=="completo") {
        $("#dina").html("");
        $("#contenido").show();
    }else{
    $("#dina").html("");
    vart=$(vari).html();
    $("#dina").html(vart);
    $("#contenido").hide();
}
}