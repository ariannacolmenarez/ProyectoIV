$("#chat").on("click", function() {
    $('#chatmodal').modal('show');
});