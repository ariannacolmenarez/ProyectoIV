<h5 class="mt-3">Cantidad disponible *</h5>
                    <div class="input-group mb-3">
                      <button class="btn btn-outline-secondary" type="button" id="minus"><i class="fa-solid fa-circle-minus"></i></button>
                      <input type="text" class="form-control text-center" placeholder="0" aria-label="Example text with button addon" aria-describedby="button-addon1" id="cantidadp">
                      <button class="btn btn-outline-secondary" type="button" id="plus"><i class="fa-solid fa-circle-plus"></i></button>
                    </div>
                    <h5 class="mt-3">Costo Unitario del producto *</h5>
                    <div class="input-group ">
                      <input type="text" class="form-control d-block w-100" placeholder="Ej: 1000" id="costop" name="costop">
                    </div>
                    <h5 class="mt-3">Precio del producto *</h5>
                    <div class="input-group ">
                      <input type="text" class="form-control d-block w-100" placeholder="Ej: 2000" id="preciop" name="preciop">
                    </div>