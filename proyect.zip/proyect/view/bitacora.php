
     <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row py-0">
            <!-- <div class="col-md-12 grid-margin">
              <div class="d-flex justify-content-between align-items-center"> -->
                <div class="col-lg-8 col-sm-4 col-6 grid-margin mb-0">
                  <h2 class="font-weight-bold text-dark pt-2 m-0">Bítacora</h2>
                </div>
              <!-- </div>
            </div> -->
          </div>
          <hr>
          



          <div class="row my-3">
            <div class="card">
                <div class="card-body" id="tableb">
                
                </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->       
        <script src="<?= _THEME_?>js/scripts/bitacora.js"></script>
