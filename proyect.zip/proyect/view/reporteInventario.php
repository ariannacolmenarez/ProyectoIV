    <div class="main-panel">
        <div class="content-wrapper">
            <div class="row py-0">
                <div class="col-lg-10 col-sm-8 col-9 grid-margin mb-0">
                    <h2 class="font-weight-bold text-dark pt-2 m-0">Reportes de Inventario</h2>
                </div>
            </div>
            <hr>
            <div class="row w-75 m-auto">
            <div class="card">
              <div class="mx-auto mt-3 btn btn-success" id='buttonDiv' style='color:white;'>
              Generar reporte
            </div>
            <div class="mx-auto mt-4 mb-4 w-100" id='insertInventario'>
            </div>
            </div>
            </div>
        </div>
    </div>
    <script src="<?= _THEME_?>js/scripts/reporteInventario.js"></script>
